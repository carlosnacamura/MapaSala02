﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace model.entidades.NewFolder1
{
    public class CursosEntidade
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int ano { get; set; }
        public string periodo { get; set; }
        public bool vagas { get; set; }
    }
}
